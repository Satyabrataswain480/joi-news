from api import create_app
from api.newsfeed import Newsfeed
import os

# Security improvement: Use environment variables instead of hardcoded tokens
valid_tokens = os.environ.get("NEWSFEED_API_TOKENS", "").split(",")
if not valid_tokens or valid_tokens == [""]:
    raise ValueError("NEWSFEED_API_TOKENS environment variable must be set")

feed_urls = [
    "https://www.martinfowler.com/feed.atom",
    "https://www.reddit.com/r/sysadmin/.rss",
]

app = create_app(valid_tokens, Newsfeed(feed_urls))
