# Cost Optimization Strategy

## Current Cost Analysis

### Identified Cost Inefficiencies
1. **Always-on VMs**: Running 3 separate VMs 24/7 regardless of usage
2. **Multiple ACR instances**: 3 Basic ACR tiers ($5/month each = $15/month)
3. **No auto-shutdown**: VMs continue running during off-peak hours
4. **Oversized storage**: Standard_LRS may be overkill for some workloads

## Cost Optimization Recommendations

### Immediate Savings (30-50% cost reduction)

#### 1. Consolidate Container Registries
**Before**: 3 separate ACR instances
**After**: 1 shared ACR with multiple repositories
**Savings**: ~$10/month

```hcl
# Replace 3 ACRs with 1 consolidated ACR
resource "azurerm_container_registry" "shared" {
  name                = "${var.prefix}sharedacr"
  resource_group_name = data.azurerm_resource_group.azure-resource.name
  location            = var.location
  sku                 = "Basic"
  admin_enabled       = false
}
```

#### 2. Migrate to Azure Container Instances (ACI)
**Before**: 3 VMs @ ~$50-100/month each
**After**: ACI with automatic scaling @ ~$20-40/month total
**Savings**: 60-80% on compute costs

#### 3. Implement Auto-shutdown for Development
```hcl
# Auto-shutdown schedule for non-production environments
resource "azurerm_dev_test_global_vm_shutdown_schedule" "main" {
  virtual_machine_id = azurerm_linux_virtual_machine.quotes.id
  location           = var.location
  enabled            = true

  daily_recurrence_time = "1900"  # 7 PM
  timezone              = "UTC"
  
  notification_settings {
    enabled = false
  }
}
```

### Medium-term Optimizations

#### 4. Spot Instances for Development/Testing
- Use Azure Spot VMs for non-production workloads
- 60-90% cost savings for dev/test environments

#### 5. Reserved Instances for Production
- 1-year Azure Reserved VM Instances
- 30-40% savings for predictable workloads

#### 6. Storage Optimization
```hcl
# Use cheaper storage tiers where appropriate
os_disk {
  caching              = "ReadWrite"
  storage_account_type = "Standard_LRS"  # Consider Premium_LRS only if needed
}
```

### Advanced Cost Controls

#### 7. Resource Tagging for Cost Tracking
```hcl
tags = {
  Environment = var.environment
  Project     = "news-aggregator"
  Owner       = "team-alpha"
  CostCenter  = "engineering"
  AutoShutdown = "enabled"
}
```

#### 8. Budget Alerts
```hcl
resource "azurerm_consumption_budget_resource_group" "main" {
  name              = "${var.prefix}-budget"
  resource_group_id = data.azurerm_resource_group.azure-resource.id

  amount     = 100  # $100/month budget
  time_grain = "Monthly"

  time_period {
    start_date = "2024-01-01T00:00:00Z"
  }

  notification {
    enabled        = true
    threshold      = 80
    operator       = "GreaterThan"
    threshold_type = "Actual"
    
    contact_emails = ["team-lead@company.com"]
  }
}
```

## Cost Monitoring Dashboard

### Key Metrics to Track
- Monthly spend by service
- Cost per user/request
- Resource utilization rates
- Idle resource identification

### Target Cost Reductions
- **Short-term (1-3 months)**: 40% reduction
- **Medium-term (3-6 months)**: 60% reduction  
- **Long-term (6+ months)**: 70% reduction with serverless migration

## Serverless Migration (Future)

### Ultimate Cost Optimization
- Azure Functions for API endpoints
- Azure Static Web Apps for frontend
- Azure Logic Apps for RSS feed processing
- Pay-per-execution model

**Estimated costs for serverless**:
- Azure Functions: $0-5/month for low traffic
- Static Web Apps: Free tier
- Logic Apps: $1-3/month
- **Total**: <$10/month vs current $150+/month
