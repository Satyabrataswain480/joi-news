from api import create_app
from api.newsfeed import Newsfeed
from api.quotes import Quotes
from os import environ
import logging

# Configure logging for better monitoring
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Service URLs with better defaults for container networking
NEWSFEED_SERVICE_URL = environ.get(
    "NEWSFEED_SERVICE_URL",
    "http://newsfeed:8081"  # Container-friendly default
)
QUOTE_SERVICE_URL = environ.get(
    "QUOTE_SERVICE_URL",
    "http://quotes:8082"  # Container-friendly default
)

# Security: Ensure token is provided
NEWSFEED_SERVICE_TOKEN = environ.get("NEWSFEED_SERVICE_TOKEN")
if not NEWSFEED_SERVICE_TOKEN:
    logger.warning("NEWSFEED_SERVICE_TOKEN not set - newsfeed service may not work")

# Health check configuration
HEALTH_CHECK_TIMEOUT = int(environ.get("HEALTH_CHECK_TIMEOUT", "5"))

logger.info(f"Starting front-end service...")
logger.info(f"Newsfeed URL: {NEWSFEED_SERVICE_URL}")
logger.info(f"Quotes URL: {QUOTE_SERVICE_URL}")

app = create_app(
    Newsfeed(NEWSFEED_SERVICE_URL, NEWSFEED_SERVICE_TOKEN),
    Quotes(QUOTE_SERVICE_URL),
    static_url=environ.get("STATIC_URL", "")
)
