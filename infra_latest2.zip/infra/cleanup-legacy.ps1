# Infrastructure Cleanup Script
# Safely removes legacy infrastructure components

Write-Host "=== Infrastructure Cleanup Script ===" -ForegroundColor Green
Write-Host ""

# Create backup first
$timestamp = Get-Date -Format "yyyy-MM-dd-HHmm"
$backupDir = ".\backup-cleanup-$timestamp"
Write-Host "Creating backup directory: $backupDir" -ForegroundColor Yellow
New-Item -ItemType Directory -Path $backupDir -Force | Out-Null

# Backup legacy folders before deletion
$legacyFolders = @("backend-support", "base", "news", "migration")

foreach ($folder in $legacyFolders) {
    if (Test-Path ".\$folder") {
        Write-Host "Backing up $folder..." -ForegroundColor Cyan
        Copy-Item ".\$folder" "$backupDir\$folder" -Recurse -Force
        Write-Host "✓ Backed up $folder to $backupDir" -ForegroundColor Green
    }
}

Write-Host ""
Write-Host "=== Legacy Components to Remove ===" -ForegroundColor Yellow

# Show what will be deleted
foreach ($folder in $legacyFolders) {
    if (Test-Path ".\$folder") {
        $size = (Get-ChildItem ".\$folder" -Recurse | Measure-Object -Property Length -Sum).Sum / 1KB
        Write-Host "📁 $folder/ ($([math]::Round($size, 2)) KB)" -ForegroundColor White
    }
}

Write-Host ""
$confirm = Read-Host "Do you want to delete these legacy folders? (y/N)"

if ($confirm -eq 'y' -or $confirm -eq 'Y') {
    Write-Host ""
    Write-Host "Deleting legacy infrastructure..." -ForegroundColor Red
    
    foreach ($folder in $legacyFolders) {
        if (Test-Path ".\$folder") {
            Remove-Item ".\$folder" -Recurse -Force
            Write-Host "✓ Deleted $folder/" -ForegroundColor Green
        }
    }
    
    Write-Host ""
    Write-Host "=== Cleanup Complete! ===" -ForegroundColor Green
    Write-Host "Your infra directory now contains only:" -ForegroundColor White
    Write-Host "✅ modules/         - Modular Terraform components" -ForegroundColor Green  
    Write-Host "✅ environments/    - Environment-specific configs" -ForegroundColor Green
    Write-Host "✅ *.ps1 scripts    - Automation scripts" -ForegroundColor Green
    Write-Host ""
    Write-Host "Backup created at: $backupDir" -ForegroundColor Yellow
    Write-Host "You can safely delete the backup after verifying everything works." -ForegroundColor Gray
    
} else {
    Write-Host "Cleanup cancelled. No files were deleted." -ForegroundColor Yellow
}

Write-Host ""
Write-Host "Next steps:" -ForegroundColor Cyan
Write-Host "1. cd environments/dev" -ForegroundColor White
Write-Host "2. terraform init" -ForegroundColor White  
Write-Host "3. terraform plan" -ForegroundColor White
Write-Host "4. terraform apply" -ForegroundColor White
