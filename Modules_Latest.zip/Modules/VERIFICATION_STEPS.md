# Terraform Verification Steps

## Quick Verification Commands

### Prerequisites
Before running any verification, ensure you have:
```powershell
# 1. Check Terraform version (must be >= 1.5)
terraform version

# 2. Check Azure CLI and login status
az account show

# 3. Navigate to the infra directory
cd infra
```

## Step-by-Step Verification

### Step 1: Run Migration Script
```powershell
# Run the migration script first
.\cleanup-and-migrate.ps1
```

### Step 2: Comprehensive Verification
```powershell
# Run the detailed verification script
.\verify-terraform.ps1
```

### Step 3: Manual Verification (if needed)

#### A. Verify Module Structure
```powershell
# Check all modules exist
Get-ChildItem -Path ".\modules" -Directory | Format-Table Name

# Validate each module individually
cd modules\networking
terraform validate
cd ..\security  
terraform validate
cd ..\compute
terraform validate
cd ..\storage
terraform validate
cd ..\container-registry
terraform validate
cd ..\monitoring
terraform validate
cd ..\load-balancer
terraform validate
cd ..\..
```

#### B. Test Development Environment
```powershell
# Navigate to development environment
cd environments\dev

# Create terraform.tfvars from example
cp terraform.tfvars.example terraform.tfvars

# Edit terraform.tfvars with your values:
# - resource_group_name = "your-dev-rg"
# - ssh_public_key = "your-ssh-public-key"
# - allowed_ssh_ips = ["your-ip/32"]
# - secrets (API keys)

# Initialize Terraform
terraform init

# Validate configuration
terraform validate

# Create execution plan
terraform plan -out=dev.tfplan

# Review the plan output
terraform show dev.tfplan
```

#### C. Test Production Environment
```powershell
# Navigate to production environment
cd ..\prod

# Create terraform.tfvars from example
cp terraform.tfvars.example terraform.tfvars

# Edit terraform.tfvars with production values

# Initialize Terraform
terraform init

# Validate configuration
terraform validate

# Create execution plan
terraform plan -out=prod.tfplan

# Review the plan output
terraform show prod.tfplan
```

## What to Look For

### ✅ Successful Validation Indicators:
- `terraform init` completes without errors
- `terraform validate` shows "Success! The configuration is valid."
- `terraform plan` creates a plan without errors
- Plan shows expected resources (VMs, networks, storage, etc.)

### ❌ Common Issues and Solutions:

#### Issue: "Module not found"
```
Solution: Ensure all modules are created in infra/modules/
Run: .\verify-terraform.ps1 to check module structure
```

#### Issue: "No terraform.tfvars file"
```
Solution: Copy and edit the example file
cp terraform.tfvars.example terraform.tfvars
# Edit with your specific values
```

#### Issue: "Authentication errors"
```
Solution: Ensure Azure CLI is logged in
az login
az account show
```

#### Issue: "Resource group not found"
```
Solution: Create the resource group first or update the name
az group create --name "your-rg-name" --location "East US"
```

## Expected Plan Output

### Development Environment (~$79/month):
```
Plan: 25 to add, 0 to change, 0 to destroy.

Resources to be created:
- Virtual Network and subnets
- 3x Virtual Machines (B-series)
- 1x Container Registry (Basic)
- 1x Storage Account (LRS)
- 1x Key Vault (Standard)
- Security groups and rules
- Network interfaces
```

### Production Environment (~$220/month):
```
Plan: 35 to add, 0 to change, 0 to destroy.

Resources to be created:
- Virtual Network with DDoS protection
- 3x Virtual Machines (D-series, multi-zone)
- 1x Container Registry (Premium)
- 1x Storage Account (GRS)
- 1x Key Vault (Premium)
- 1x Load Balancer
- Monitoring and alerting
- Security groups and rules
```

## Deployment Commands

### After Successful Verification:

#### Deploy Development:
```powershell
cd environments\dev
terraform apply dev.tfplan
```

#### Deploy Production:
```powershell
cd ..\prod
terraform apply prod.tfplan
```

#### Get Deployment Information:
```powershell
# Get application URLs
terraform output application_urls

# Get all outputs
terraform output
```

## Troubleshooting

### Debug Commands:
```powershell
# Enable detailed logging
$env:TF_LOG = "DEBUG"
terraform plan

# Check specific resource status
terraform state list
terraform state show <resource_name>

# Refresh state
terraform refresh
```

### Recovery Commands:
```powershell
# If deployment fails, check state
terraform state list

# Remove problematic resources
terraform state rm <resource_name>

# Re-import existing resources
terraform import <resource_type>.<name> <azure_resource_id>
```

## Success Criteria

✅ **Verification Complete When:**
- All modules validate successfully
- Environment configurations pass `terraform plan`
- No authentication or permission errors
- Resource counts match expectations
- Cost estimates align with projections

✅ **Ready for Deployment When:**
- Verification script completes without errors
- terraform.tfvars configured with correct values
- Azure permissions are sufficient
- Resource group exists
- Plan output looks reasonable

🎉 **Migration Success Indicators:**
- 57% cost reduction achieved
- All security vulnerabilities addressed
- Modular structure enables faster deployments
- Environment isolation working correctly
